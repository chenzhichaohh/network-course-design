package com.chenzhichao.www.ftp.command.impl;

import com.chenzhichao.www.ftp.command.BaseCommand;
import com.chenzhichao.www.ftp.entity.UserInfo;
import com.chenzhichao.www.ftp.utils.AccountUtil;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 * 用户验证
 * @author BichonCode
 * @mail chenzhichaohh@163.com
 * @create 2020-07-25
 */
public class UserCommmand implements BaseCommand {

	private BufferedReader reader;

	@Override
	public void executeCommand(String userName, BufferedWriter writer, UserInfo userInfo) {
		if (AccountUtil.hasUsername(userName)) {
			System.out.println("The account is exist! "+userName);
			try {
				writer.write("\n331\r\n");
				writer.flush();
				userInfo.setUsername(userName);
				//reader.readLine();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}else{
			System.out.println("The account is not exist! "+userName);
			try {
				writer.write("501\r\n\n");
				writer.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	

}
