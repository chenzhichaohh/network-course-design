package com.chenzhichao.www.ftp.server;

import com.chenzhichao.www.ftp.utils.Md5Util;

/**
 * @author BichonCode
 * @mail chenzhichaohh@163.com
 * @create 2020-07-25
 */
public class TestMD5 {
    public static void main(String[] args) {
        String passWord = "123456";
        String passWord2Md5 = Md5Util.encoder(passWord);
        System.out.println(passWord2Md5);
    }
}
